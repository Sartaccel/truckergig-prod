export { default } from "./Landing";
